<!-- If you're reporting a bug, please provide the following information to make it easier to triage your issue. If you don't provide this information, your issue may be closed. If a question isn't applicable to your report, feel free to skip it/delete it. -->

**What version of `eslint` are you using?**

**What version of `prettier` are you using?**

**What version of `eslint-plugin-prettier` are you using?**

**Please paste any applicable config files that you're using (e.g. `.prettierrc` or `.eslintrc` files)**

**What source code are you linting?**

**What did you expect to happen?**

**What actually happened?**
