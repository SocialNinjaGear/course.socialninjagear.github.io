import { ESLint } from 'eslint';

declare const eslintPluginPrettier: ESLint.Plugin;

export = eslintPluginPrettier;
