import { Linter } from 'eslint';

declare const recommendedConfig: Linter.FlatConfig;

export = recommendedConfig;
