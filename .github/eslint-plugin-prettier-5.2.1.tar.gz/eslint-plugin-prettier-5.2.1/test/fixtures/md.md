# Heading

```ts
export declare const x = 1
```
